import React from "react";

const Home = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <h1>Home Page</h1>
        </div>
      </div>
    </div>
  );
};

export default Home;
