const User = require("../models/User");
const { hashPassword, comparePassowrd } = require("../helpers/auth");

// handler to handle user registerations
exports.registerAuth = async (req, res) => {
  const { name, email, password, secret } = req.body;

  if (!name || name.length == 0)
    return res.status(400).send("Name is required");
  if (!email || email.length == 0)
    return res.status(400).send("Email is required");
  if (!password || password.length < 6 || password.length == 0)
    return res
      .status(400)
      .send("Password is required & should be atleast 6 characters long");
  if (!secret || secret.length == 0)
    return res.status(400).send("Answer is required");

  try {
    const doesExist = await User.findOne({ email }).exec();
    if (doesExist) return res.status(400).send("Email already exist");

    // hash the password
    const hashedPass = await hashPassword(password);

    const createUser = new User({
      name,
      email,
      password: hashedPass,
      secret,
    });

    await createUser.save();
    return res.json({ ok: true });
  } catch (error) {
    res.status(500).send("Error. Try again...");
  }
};
