const router = require("express").Router();
const { registerAuth } = require("../controllers/auth");

router.post("/register", registerAuth);

module.exports = router;
